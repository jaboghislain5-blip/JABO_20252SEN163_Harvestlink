Season B: Crop Production
=========================

Summary: This table presents plot-level data on crop production during Season B (March – June 2024) of the 2023/2024 Seasonal Agricultural Survey (SAS) conducted by the National Institute of Statistics of Rwanda. Each record represents a specific agricultural plot and the crops produced on it by the farming household during the reference season. The table includes information on crop identification and seed use (type, source, and purchase costs), quantities harvested and remaining, utilization of production across channels such as household consumption, sales, storage, and other uses, as well as post-harvest losses disaggregated by causes including theft, pests, animals, and losses during harvesting, transport, and storage.

Geographic Coverage: National coverage across Rwanda, including all provinces and districts, capturing crop production in both rural and peri-urban areas.

Time Period: Season B of the 2023/2024 agricultural year, covering the period from March to June 2024.

Frequency: Seasonal (three times per year: Seasons A, B, and C).

Population/Units: Agricultural plots managed by small-scale and large-scale farming households in Rwanda.

Key Variables: Crop type, seed type and source, seed costs, quantities harvested, quantities remaining, production utilization (consumption, sales, storage, other uses), and post-harvest losses by cause.

Purpose: The table supports analysis of crop production, utilization patterns, and post-harvest losses at the plot and household level, informing agricultural policy, food security monitoring, and planning.

Data Quality Notes: The data reflect reported production and utilization at the plot level for surveyed households and may not fully represent all farming activities nationwide. Reporting accuracy and coverage may vary across regions and respondents.
